# CH Ananya Portfolio

## How to publish on GitHub Pages

1. Create a GitHub repository named `chananya-6617.github.io`.
2. Upload `index.html` and `style.css`.
3. Open the repository's **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main`, and save.
5. Your portfolio URL will be:

https://chananya-6617.github.io

Before publishing, replace `your-email@example.com` in `index.html` with your real email address.
